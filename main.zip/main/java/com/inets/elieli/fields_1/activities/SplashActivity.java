package com.inets.elieli.fields_1.activities;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;

import com.inets.elieli.fields_1.MainActivity;
import com.inets.elieli.fields_1.R;
import com.wang.avi.AVLoadingIndicatorView;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {
    AVLoadingIndicatorView avi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView textCurl = (TextView) findViewById(R.id.splash_text);

        String fontPath = "fonts/aqua.ttf";

        // Loading Font Face
        Typeface tf = Typeface.createFromAsset(getAssets(), fontPath);

        // Applying font

        textCurl.setTypeface(tf);

        String indicator=getIntent().getStringExtra("indicator");
        avi= (AVLoadingIndicatorView) findViewById(R.id.avi);
        avi.setIndicator(indicator);
        avi.show();

        Timer timer = new Timer();
        timer.schedule(new TimerTask(){
            @Override
            public void run() {
                // TODO start activity login
                Intent home_page = new Intent(SplashActivity.this,LoginActivity.class);
                startActivity(home_page);
                finish();
            }}, 3000);


    }

//    void startAnim(){
//        avi.show();
//        // or avi.smoothToShow();
//    }
//
//    void stopAnim(){
//        avi.hide();
//        // or avi.smoothToHide();
//    }

}
