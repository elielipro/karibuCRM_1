package com.inets.elieli.fields_1.app;

/**
 * Created by elieli on 9/5/16.
 */
public class AppConfig {
    //login url
    public static String URL_LOGIN = "https://api.myjson.com/bins/1qrt0";
   // get fields url
    public static String URL_FIELDS = "https://api.myjson.com/bins/33cq4";//http://192.168.8.106/project1/public/mobile?tag=get_list

    //submission url
    public static String URL_SUBMIT ="http://192.168.8.105/project1/public/mobile?tag=store_user";
    //picture upload url
    public static String URL_UPLOAD ="http://VolleyUpload/upload.php";
}
